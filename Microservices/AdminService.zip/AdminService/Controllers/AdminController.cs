﻿using AdminService.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AdminService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly ILogger<AdminController> _logger;
        private readonly IAdminService _adminService;

        public AdminController(IAdminService adminService, ILogger<AdminController> logger)
        {
            _adminService = adminService ?? throw new ArgumentNullException(nameof(adminService));
            this._logger = logger;
        }

        [HttpGet]
        [Route("/GetMenu")]
        public async Task<IActionResult> GetMenu(int id)
        {
            try
            {
                _logger.LogInformation("GetMenu API started at:" + DateTime.Now);
                var result = _adminService.GetMenu(id);
                return Ok(result);

            }
            catch (Exception ex)
            {
                _logger.LogError("GetMaterailInfo API Error :", ex.Message);
                return StatusCode(500, new { Message = ex.Message, Details = ex.InnerException?.Message });
            }

        }
 
    }
}
