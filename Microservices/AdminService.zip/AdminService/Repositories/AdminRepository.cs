﻿using AdminService.Context;
using AdminService.Interfaces;
using Newtonsoft.Json;
using SupplierService.Models;

namespace AdminService.Repositories
{
    public class AdminRepository : IAdminService
    {
        private AdminServiceContext _dbContext;
        private readonly IConfiguration _configuration;
        private readonly ILogger<AdminRepository> _logger;

        public AdminRepository(IConfiguration configuration, ILogger<AdminRepository> logger, AdminServiceContext adminServiceContext)
        {
            _dbContext = adminServiceContext;
            _configuration = configuration;
            this._logger = logger;
        }

        public string GetMenu(int id)
        {
            _logger.LogInformation("GetMenus API started at:" + DateTime.Now);

            List<MSTMenu_Useraccess> childrenhResult = new List<MSTMenu_Useraccess>();

            string output = "";
            try
            {
                if (id > 0)
                {
                    IList<MSTMenu_Useraccess> _MSTMenuchildren = new List<MSTMenu_Useraccess>();

                    List<MSTMenu_Useraccess> _MSTMenu = new List<MSTMenu_Useraccess>();

                    _MSTMenu = (from a in _dbContext.MST_Menu
                                join b in _dbContext.RELRoleMenu on a.MenuId equals b.MenuId
                                where a.Status == true && a.MenuCategory == "M1" && b.RoleId == id

                                select new MSTMenu_Useraccess
                                {
                                    value = a.MenuId,
                                    Menu = a.Menu,
                                    text = a.SubMenu,
                                    Navigate_Url = a.Navigate_Url

                                }).OrderBy(x => x.value).ToList();

                    for (int i = 0; i < _MSTMenu.Count; i++)
                    {
                        MSTMenu_Useraccess subMenus = new MSTMenu_Useraccess
                        {
                            value = _MSTMenu[i].value,
                            Menu = _MSTMenu[i].Menu,
                            text = _MSTMenu[i].text,
                            Navigate_Url = _MSTMenu[i].Navigate_Url,
                            children = GetsubMenus(_MSTMenu[i].text, id)
                        };
                        childrenhResult.Add(subMenus);
                    }

                    output = JsonConvert.SerializeObject(childrenhResult, Newtonsoft.Json.Formatting.Indented);

                }

            }

            catch (Exception ex)
            {
                _logger.LogError("GetMenus API error :" + ex.Message);
            }
            return output;
        }

        public List<MSTMenu_Useraccess> GetsubMenus(string MenuName, int rollId)
        {
            _logger.LogInformation("GetsubMenus API started at:" + DateTime.Now);
            try
            {
                List<MSTMenu_Useraccess> _MSTMenus = new List<MSTMenu_Useraccess>();
                _MSTMenus = (from a in _dbContext.MST_Menu
                             join b in _dbContext.RELRoleMenu on a.MenuId equals b.MenuId
                             where a.Status == true && a.MenuCategory == "M2" && b.RoleId == rollId && a.Menu == MenuName
                             select new MSTMenu_Useraccess
                             {
                                 value = a.MenuId,
                                 Menu = a.Menu,
                                 text = a.SubMenu,
                                 Navigate_Url = a.Navigate_Url

                             }).OrderBy(x => x.value).ToList();
                return _MSTMenus;
            }
            catch (Exception ex)
            {
                _logger.LogError("GetsubMenus API error :" + ex.Message);
                throw;
            }

        }


    }
}
