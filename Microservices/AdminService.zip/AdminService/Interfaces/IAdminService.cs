﻿namespace AdminService.Interfaces
{
    public interface IAdminService
    {
        string GetMenu(int id);
    }
}
