﻿using Microsoft.AspNetCore.Rewrite;
using SupplierService.Models;

namespace SupplierService.Interfaces
{
    public interface ISupplierService
    {
        List<SupplierInfo> GetMaterialInfo();

        List<POHeader> GetPOHeader();

        List<int> GetPONumber();

        //List<POItemDetails> GetPOItemDetails(int ponumber);

        List<POItemLotDetails> GetPODetails(int ponumber);

        Task<bool> UpsertLotDetails(List<UpsertLotDetails> POList);

        List<Usermastercs> Getusermaster();

        List<Getrole> Getroles();
        Task<int> Adduserdata(Adduser user);
        Task<int> UpdateUserData(Updateuser user);

        Task<int> DeleteUserData(int userId);
        List<podetails> podetails();
        Task<List<GetRolesDetails>> GetRoleInfo();
        Task<int> AddRoleData(AddRoleData user);
        Task<int> UpdateRoleData(UpdateRoleData user);
        string GetMenu(int id);
    }

}
