﻿namespace SupplierService.Models
{
    public class AddRoleData_new
    {
        public string? Role_name { get; set; }
        public string? Description { get; set; }
        public string? MenuId { get; set; }
        public bool CreatedBy { get; set; }
    }

}
