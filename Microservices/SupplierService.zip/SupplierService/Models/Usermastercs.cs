﻿namespace SupplierService.Models
{
    public class Usermastercs
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Role { get; set; }
        public int MST_Role_Id { get; set; }
        public string Status { get; set; }
        public string Fullname { get; set; }
        public string EmaildId { get; set; }
        public string Created_by { get; set; }
        public DateTime Created_Date { get; set; }
    }
}
