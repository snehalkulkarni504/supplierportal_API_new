﻿
using Microsoft.EntityFrameworkCore;
using SupplierService.Models;

namespace SupplierService.Context
{
    public class SupplierServiceContext : DbContext
    {
        protected readonly IConfiguration Configuration;

        public SupplierServiceContext(DbContextOptions options) : base(options)
        {
            // TODO: This seems a bit too long. Why has this been set this high?
            //Database.SetCommandTimeout(180);
        }

        public virtual DbSet<GetMenu> MST_Menu { get; set; }
        public virtual DbSet<RELRoleMenu> RELRoleMenu { get; set; }
        public virtual DbSet<GetRolesDetails> Roleresults { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<GetRolesDetails>(entity => entity.HasNoKey()); 

            modelBuilder.Entity<GetMenu>(entity =>
            {
                entity
                    .ToTable("MST_Menu")
                    .HasKey(x => x.MenuId);
            });

            modelBuilder.Entity<RELRoleMenu>(entity =>
            {
                entity
                    .ToTable("REL_RoleMenu")
                    .HasKey(x => x.Rel_RoleMenuId);
            });
        }
    }
}
